<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <?php 
      include '../menu.php';
      include "../config.php";

      $stmt = $db->prepare("SELECT * FROM makes ORDER BY NAME;");
      $stmt->execute();
      $makes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    ?>
    <div class="container mt-3">
        <form method="POST">
              <div class="form-group">
                <label for="exampleInputEmail1">Регистрационен Номер</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="reg_num" required>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail2">Марка</label>
                <select class="form-control" id="exampleInputEmail2" name="make_id">

                <?php
                  foreach($makes as $make) {

                    $id = $make['id'];
                    $name = $make['name'];
                    echo "<option value=\"$id\">$name</option>";
                  }
                ?>

                </select>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail3">Модел</label>
                <input type="text" class="form-control" id="exampleInputEmail3" name="model" required>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail4">Брой пасажери</label>
                <input type="number" class="form-control" id="exampleInputEmail4" name="pass_count" required min="1" max="10">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail5">Има голям багажник</label>
                <input type="checkbox" class="form-control" id="exampleInputEmail5" name="large_boot" style="width: auto">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail6">Валидност на технически преглед</label>
                <input type="date" class="form-control" id="exampleInputEmail6" name="passed_technical_check" required>
              </div>
              <button type="submit" class="btn btn-primary">Създай</button>
        </form>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</html>

<?php

if(isset($_POST['reg_num'])) {

    include "../config.php";

    $registNum = $_POST['reg_num'];
    $makeId = $_POST['make_id'];
    $model = $_POST['model'];
    $passCount = $_POST['pass_count'];
    $largeBoot = intval(isset($_POST['large_boot']));
    $passedTechnicalCheck = $_POST['passed_technical_check'];

    try {
        $statement = $db->prepare("INSERT INTO cars (reg_num, make_id, model, passengers, large_boot, passed_technical_check)
        VALUES('$registNum', $makeId, '$model', $passCount, $largeBoot, '$passedTechnicalCheck')");
        
        $statement->execute();
    
        echo "Добавена е запис.";
    }
    catch(Exception $ex) {
        echo "Невалидна информация.";
    }
}

