<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <?php include '../menu.php'; ?>
    <div class="container mt-3">
        <?php

            include "../config.php";

            $id = $_GET['id'];
            $statement = $db->prepare("SELECT * FROM  cars INNER JOIN makes ON makes.id =  cars.make_id WHERE cars.id = $id");

            $statement->execute();
            $r = $statement->fetchAll(PDO::FETCH_ASSOC);
            if(count($r) == 0) {var_dump($r);
                echo 'Невалиден идентификатор.';
                return;
            }
            else  {

            $r = $r[0]; 

            $stmt = $db->prepare("SELECT * FROM makes ORDER BY NAME;");
            $stmt->execute();
            $makes = $stmt->fetchAll(PDO::FETCH_ASSOC);
         
         ?>

          <form method="GET">
              <div class="form-group">
                <label for="exampleInputEmail1">Регистрационен Номер</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="reg_num" required
                value="<?php echo $r['reg_num']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail2">Марка</label>
                <select class="form-control" id="exampleInputEmail2" name="make_id">

                <?php
                  foreach($makes as $make) {

                    $makeID = $make['id'];
                    $name = $make['name'];
                    echo "<option value=\"$makeID\"";
                    if($make['id'] == $r['make_id']) echo 'selected';
                    echo ">$name</option>";
                  }
                ?>

                </select>
              </div>
              <div class="form-group">
                <label for="exampleInputEmail3">Модел</label>
                <input type="text" class="form-control" id="exampleInputEmail3" name="model" required
                value="<?php echo $r['model']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail4">Брой пасажери</label>
                <input type="number" class="form-control" id="exampleInputEmail4" name="pass_count" required min="1" max="10"
                value="<?php echo $r['passengers']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail5">Има голям багажник</label>
                <input type="checkbox" class="form-control" id="exampleInputEmail5" name="large_boot" style="width: auto" <?php if($r['large_boot']) echo 'checked'; ?> >
              </div>
              <div class="form-group">
                <label for="exampleInputEmail6">Валидност на технически преглед</label>
                <input type="date" class="form-control" id="exampleInputEmail6" name="passed_technical_check" required
                value="<?php echo $r['passed_technical_check']?>">
              </div>

              <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">

              <button type="submit" class="btn btn-primary">Редактирай</button>
        </form>

        <?php } ?>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</html>

<?php

if(isset($_GET['reg_num'])) {

    include "../config.php";

    $registNum = $_GET['reg_num'];
    $makeId = $_GET['make_id'];
    $model = $_GET['model'];
    $passCount = $_GET['pass_count'];
    $largeBoot = intval(isset($_GET['large_boot']));
    $passedTechnicalCheck = $_GET['passed_technical_check'];

    try {
        $statement = $db->prepare("UPDATE cars 
        SET reg_num = '$registNum', 
        make_id = $makeId,
        model = '$model',
        passengers = $passCount,
        large_boot = $largeBoot,
        passed_technical_check = '$passedTechnicalCheck'
        WHERE ID = $id");

        $statement->execute();
    
        echo "Редактиран запис.";
    }
    catch(Exception $ex) {
        echo "Невалидна информация.";
    }
}

