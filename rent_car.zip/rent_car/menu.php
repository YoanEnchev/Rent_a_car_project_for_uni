<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Наемане на коли</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Начало</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="clients" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Клиенти
        </a>
        <div class="dropdown-menu" aria-labelledby="clients">
          <a class="dropdown-item" href="/rent_car/clients/index.php">Списък</a>
          <a class="dropdown-item" href="/rent_car/clients/create.php">Създаване</a>
        </div>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="cars" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Коли
        </a>
        <div class="dropdown-menu" aria-labelledby="cars">
          <a class="dropdown-item" href="/rent_car/cars/index.php">Списък</a>
          <a class="dropdown-item" href="/rent_car/cars/create.php">Създаване</a>
        </div>
      </li>
    </ul>
  </div>
</nav>