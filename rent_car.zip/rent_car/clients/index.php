<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <?php 
    include '../menu.php';
    include "../config.php";

    $stmt = $db->prepare("SELECT * FROM  clients");
    $stmt->execute();
    $clients = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>

    <div class="container mt-3">
        <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Име</th>
            <th scope="col">Фамилия</th>
            <th scope="col">ЕГН</th>
            <th scope="col">Адрес</th>
            <th scope="col">Код на шофьорска книжка</th>
            <th scope="col">Валидност на шофьорска книжка</th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($clients as $client) { ?>
        <tr>
            <td scope="row"><?php echo $client['first_name'] ?> </td>
            <td class="fac-num"><?php echo $client['family_name'] ?></td>
            <td><?php echo $client['egn'] ?></td>
            <td><?php echo $client['address'] ?></td>
            <td><?php echo $client['driving_license_code']?></td>
            <td><?php echo $client['driving_license_valid_until']?></td>
            <td>
                <a class="btn btn-dark text-white" href="/rent_car/clients/edit.php?id=<?php echo $client['id']?>">Редактирай</a>
                <a class="btn btn-danger text-white" href="/rent_car/clients/delete.php?id=<?php echo $client['id']?>">Изтрий</a>
            </td>
        </tr>
        <?php }?>
        </tbody>
        </table>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</html>

<?php
/*
if(isset($_POST['zanr'])) {

    include "config.php";

    $statement = $db->prepare("INSERT INTO books (genre, price, year, quantity)
    VALUES ($_POST['zanr'], $_POST['price'], $_POST['god'], $_POST['kol']);");
    
    $statement->execute();

    echo "Добавена е нова книга.";
}*/

