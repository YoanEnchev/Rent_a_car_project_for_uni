<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <?php include '../menu.php'; ?>
    <div class="container mt-3">
        <?php

            include "../config.php";

            $id = $_GET['id'];
            $statement = $db->prepare("SELECT * FROM clients WHERE id = $id");

            $statement->execute();
            $r = $statement->fetchAll(PDO::FETCH_ASSOC);
            if(count($r) == 0) {
                echo 'Невалиден идентификатор.';
                return;
            }
            else  {

            $r = $r[0]; 
         
         ?>

        <form method="GET">
              <div class="form-group">
                <label for="exampleInputEmail1">Име</label>
                <input type="text" class="form-control" id="exampleInputEmail1" name="name" required value="<?php echo $r['first_name']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail2">Фамилия</label>
                <input type="text" class="form-control" id="exampleInputEmail2" name="family" required value="<?php echo $r['family_name']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail3">ЕГН</label>
                <input type="text" class="form-control" id="exampleInputEmail3" name="egn" required value="<?php echo $r['egn']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail4">Адрес</label>
                <input type="text" class="form-control" id="exampleInputEmail4" name="address" required value="<?php echo $r['address']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail5">Номер на шофьорска книжка</label>
                <input type="text" class="form-control" id="exampleInputEmail5" name="license_num" required value="<?php echo $r['driving_license_code']?>">
              </div>
              <div class="form-group">
                <label for="exampleInputEmail6">Валидност на шофьорска книжка</label>
                <input type="date" class="form-control" id="exampleInputEmail6" name="license_validity" required value="<?php echo $r['driving_license_valid_until']?>">
              </div>
              <button type="submit" class="btn btn-primary">Редактирай</button>

              <input type="hidden" name="id" value="<?php echo $_GET['id'] ?>">
        </form>

        <?php } ?>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</html>

<?php

if(isset($_GET['name'])) {

    include "../config.php";

    $name = $_GET['name'];
    $family = $_GET['family'];
    $egn = $_GET['egn'];
    $address = $_GET['address'];
    $licenseNum = $_GET['license_num'];
    $licenseValidity = $_GET['license_validity'];
    $id = $_GET['id'];

    //try {
        $statement = $db->prepare("UPDATE clients 
        SET first_name = '$name', 
        family_name = '$family',
        egn = '$egn',
        `address` = '$address',
        driving_license_code = '$licenseNum',
        driving_license_valid_until = '$licenseValidity'
        WHERE ID = $id");

        $statement->execute();
    
        echo "Редактиран запис.";
    /*}
    catch(Exception $ex) {
        echo "Невалидна информация.";
    }*/
}

